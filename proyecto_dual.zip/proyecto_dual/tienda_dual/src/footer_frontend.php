<!-- pie de página -->
<div class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-col-1">
                <h3>Descargar</h3>
                <p>asdsdaasdda</p>
            </div>
            <div class="footer-col-2">
                <img src="img/logo.png">
                <p>asdsdaasdda</p>
            </div>
            <div class="footer-col-3">
                <h3>RRSS</h3>
                <ul>
                    <li>Twitter</li>
                    <li>Youtube</li>
                </ul>
            </div>
        </div>
        <hr>
        <p class="copyright">Copyright &copy; 2023</p>
    </div>
</div>
<?php
// Conexión a la base de datos
$mysqli = new mysqli("localhost", "root", "root", "tienda_dual");
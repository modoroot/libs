<?php
//token para encriptar el id de la categoría y del producto para evitar que se pueda cambiar
// a mano y acceder a otra página web
const KEY_TOKEN = "XIT-.R4G-*";
